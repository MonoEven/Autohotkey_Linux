# 16. 真实风格 AHK Migration Corpus：15 个验收脚本设计

这是一套**建议验收设计与迁移预判，不是已经执行的 15-script pass rate**。每个脚本都应保留官方 Windows v2.0.26 baseline，并用独立输入 producer 和目标应用 recorder 验证。路径、可执行文件名与目标窗口 class 的 Linux 调整不视为语言语义失败。

U=unchanged；T=trivial Linux adaptation；M=moderate rewrite；R=major rewrite；X=在现有平台/API 下无法 unchanged 实现；?=关键环境未经证明。`†`表示尤其需要安全/可靠性验收，不建议直接作为全天依赖。GNOME/KDE 列按 native Wayland 工作流评估，不借用 XWayland 成功冒充 native 成功。

| Script | 核心语义/目标 | X11 | XWayland | GNOME native | KDE native | wlroots | Migration effort |
|---|---|---|---|---|---|---|---|
| 01 app_launcher.ahk | Ctrl+Alt 热键启动/聚焦应用 | T | T | T/? | T/? | T/? | 改进程路径、窗口身份、权限 |
| 02 caps_navigation.ahk | Caps 前缀 + hjkl，tap-alone | M† | M† | M/R† | M/R† | M† | 需要可靠 suppression、prefix、物理层 |
| 03 vim_remap.ahk | 应用内 remap，modifier保持 | T/M† | M† | M/R† | M/R† | M† | 语义中心路径，不能只比字符 |
| 04 text_expansion.ahk | 多 Hotstring，大小写/终止字符 | U/T | U/T | M/? | M/? | M/? | capture与replacement backend是关键 |
| 05 chinese_expansion.ahk | 拼音commit→中文Hotstring | T | T（IBus证据最强） | M/? | M/? | M/? | 真实 IME/target 生命周期待验 |
| 06 app_hotif.ahk | 窗口条件、失焦立即pass-through | T | T/M | R/? | R/? | M/R | WinActive身份与动态抑制 |
| 07 command_palette.ahk | InputHook collect/end/cancel/GUI | U/T† | T/M† | M/R? | M/R? | M? | native全局capture不可从portal推导 |
| 08 clipboard_history.ahk | watcher去重、选择恢复文本 | T† | T† | M† | M/?† | M† | 并发ownership和重启需要补强 |
| 09 rich_clipboard.ahk | text+HTML+PNG+URI snapshot/restore | M† | M† | R/X | R/X | R/X | 当前native rich缺口；X11 paste也会文本化 |
| 10 window_tiler.ahk | 列表、定位、resize、restore | T | T/M | R/X | R/X | R/M | desktop-specific API，不是通用Win32 |
| 11 launcher_gui.ahk | 控件/resize/搜索/启动/定时器 | T | T | T/M? | T/M? | T/M? | GUI本身较实用，目标/依赖仍需适配 |
| 12 form_automation.ahk | Text/EditableText/Action/Value | M | M | M/R | M/R? | M/R? | toolkit accessibility决定成功 |
| 13 browser_a11y.ahk | 导航、表单、按钮、读回 | M/R? | M/R? | M/R? | M/R? | M/R? | 真实浏览器应用流程缺强oracle |
| 14 editor_automation.ahk | 编辑文本、选区、命令、读回 | M/R | M/R | M/R | M/R? | M/R? | Monaco源码不可由占位AT-SPI文档读取 |
| 15 power_user_suite.ahk | A热键+B扩展+CInputHook+Dremap+Eclipboard | M† | M† | R/?† | R/?† | M/R† | 多脚本仲裁/全天/重启是当前最大综合门槛 |

### 每个脚本必须验收什么
| Script | 驱动/故障序列 | 不由被测 runtime 自己决定的 oracle |
|---|---|---|
| 01 | 连续按、重复按、应用已开/未开、焦点变化 | 进程 PID、目标焦点/窗口数 |
| 02 | 前缀单击、长按、wrong second、rollover、掉线 | 原键是否到目标、方向键精确 down/up |
| 03 | Ctrl/Shift held、remap recursion、目标切换 | 目标实际按键流及选区/文本 |
| 04 | 大小写、单词中、结束符、rapid input | 非 AHK 编辑器最终文本 |
| 05 | preedit更新、取消、候选、Backspace、focus change | IME commit日志 + GTK/Qt target文本 + callbacks exactly once |
| 06 | HotIf true/false交错、耗时条件、deadline | 原键在false/timeout时无损到目标 |
| 07 | cancel/end/timeout、重复启动、GUI关闭、Unicode | buffer字节/事件序列与独立input trace |
| 08 | 外部复制A/B/C、两脚本、owner exit | 不丢最新C、通知不重复、不自激循环 |
| 09 | 多MIME、32MiB边界、slow owner、INCR、restart | 每个format hash与ownership generation |
| 10 | 多窗口、同名、不同PID、WM拒绝请求 | WM/compositor实际geometry/state，而不是API返回值 |
| 11 | 缩放/resize、筛选、键盘焦点、IME、child failure | 独立UI自动化、可访问控件内容、子进程/文件 |
| 12 | GTK/Qt/Java/LO同义控件、readonly/timeout | 各应用自己的marker/readback，明确errno |
| 13 | Firefox/Chromium登录外测试表单、隐藏/disabled元素 | 浏览器DOM或应用自记录结果，不用port自读代替全部oracle |
| 14 | VS Code/其他编辑器同内容、选择、Undo/redo | 保存文件diff、选区、命令结果；Monaco访问缺口需替代渠道 |
| 15 | 24h、五脚本、多键盘、kill/restart/revoke/suspend | 外部事件计数、down/up balance、latency和资源指标 |

### 语义种子（设计，不声称通过）
01 使用 `^!F12::Run(...)` 与 WinActivate；02 使用 `CapsLock & h/j/k/l` 及 prefix-alone；03 使用 `#HotIf WinActive(...)` 和 remap；04 使用 `:*:;addr::...`；05 使用中文 commit 作为 Hotstring 输入；06 在目标窗口切换时测 HotIf；07 用 InputHook 的 OnChar/EndKey/timeout；08 用 OnClipboardChange 去重；09 用 ClipboardAll 保存和恢复；10 用 WinGetList/WinMove；11 用 Gui/ListBox/TreeView/Edit/Timer；12 用 ControlSetText/ControlClick/Value；13、14 明确区分 accessibility 与应用专用 API；15 用独立五进程启动这些负载，不在一个进程内假装多脚本。

