/* Contract probe, NOT an ahk_core execution.
 * Two independent X11 connections demonstrate a valid interleaving between
 * XGetSelectionOwner and XSetSelectionOwner(..., CurrentTime).
 */
#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
static void check(int ok, const char *s) { if (!ok) { perror(s); exit(2); } }
int main(void) {
    int go[2], done[2]; check(!pipe(go) && !pipe(done), "pipe");
    pid_t pid = fork(); check(pid >= 0, "fork");
    if (!pid) {
        close(go[1]); close(done[0]);
        Display *c = XOpenDisplay(NULL); check(c != NULL, "child display");
        Atom sel = XInternAtom(c, "CLIPBOARD", False);
        Window cw = XCreateSimpleWindow(c, DefaultRootWindow(c), 0,0,1,1,0,0,0);
        char b; check(read(go[0], &b, 1) == 1, "child barrier");
        XSetSelectionOwner(c, sel, cw, CurrentTime); XSync(c, False);
        check(write(done[1], &cw, sizeof cw) == sizeof cw, "child notify");
        check(read(go[0], &b, 1) == 1, "child finish");
        XCloseDisplay(c); return 0;
    }
    close(go[0]); close(done[1]);
    Display *p = XOpenDisplay(NULL); check(p != NULL, "parent display");
    Atom sel = XInternAtom(p, "CLIPBOARD", False);
    Window ours = XCreateSimpleWindow(p, DefaultRootWindow(p),0,0,1,1,0,0,0);
    XSetSelectionOwner(p, sel, ours, CurrentTime); XSync(p, False);
    int still_ours = XGetSelectionOwner(p, sel) == ours;
    check(still_ours, "precondition");
    check(write(go[1], "g", 1) == 1, "go");
    Window copied; check(read(done[0], &copied, sizeof copied) == sizeof copied, "done");
    Window before = XGetSelectionOwner(p, sel);
    if (still_ours) XSetSelectionOwner(p, sel, ours, CurrentTime);
    XSync(p, False);
    Window after = XGetSelectionOwner(p, sel);
    printf("check_was_ours=%d\nforeign_copy_before_restore=%d\nforeign_copy_preserved=%d\n", still_ours, before == copied, after == copied);
    check(write(go[1], "x", 1) == 1, "finish");
    waitpid(pid, NULL, 0); XCloseDisplay(p);
    return (before == copied && after == ours) ? 0 : 3;
}
