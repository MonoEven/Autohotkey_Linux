/* Contract probe, NOT an ahk_core execution.
 * Mirrors the return-0 I/O error handler in frozen commit 47d1fcc.
 */
#include <X11/Xlib.h>
#include <stdio.h>
#include <unistd.h>
static int return_zero(Display *d) {
    (void)d;
    fprintf(stderr, "HANDLER_CALLED: returning 0\n");
    fflush(stderr);
    return 0;
}
int main(void) {
    Display *d = XOpenDisplay(NULL);
    if (!d) { fprintf(stderr, "OPEN_FAILED\n"); return 2; }
    XSetIOErrorHandler(return_zero);
    fprintf(stdout, "READY\n"); fflush(stdout);
    for (int i = 0; i < 500; ++i) {
        XNoOp(d); XSync(d, False); usleep(20000);
    }
    fprintf(stdout, "SURVIVED\n"); fflush(stdout);
    return 0;
}
