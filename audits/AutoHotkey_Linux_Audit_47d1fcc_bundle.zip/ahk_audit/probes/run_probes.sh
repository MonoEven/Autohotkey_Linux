#!/bin/sh
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
Xvfb -displayfd 3 -screen 0 640x480x24 -nolisten tcp 3>"$D/display" >"$D/xvfb.log" 2>&1 &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true' EXIT HUP INT TERM
n=0
while [ ! -s "$D/display" ] && [ "$n" -lt 50 ]; do sleep .05; n=$((n+1)); done
export DISPLAY=:$(cat "$D/display")
{
  date -u '+date_utc=%Y-%m-%dT%H:%M:%SZ'
  echo 'target_commit=47d1fcc2873004f03ba2ee6cc2b1e6e4cada320f'
  echo 'scope=isolated_libX11_contract_probes_not_repository_runtime'
  printf 'libX11='; pkg-config --modversion x11
  "$D/clipboard_owner_race_probe"
} >"$D/results.txt" 2>&1
"$D/xio_return_probe" >"$D/xio.stdout" 2>"$D/xio.stderr" &
cpid=$!
n=0
while ! grep -q READY "$D/xio.stdout" && [ "$n" -lt 50 ]; do sleep .05; n=$((n+1)); done
kill -9 "$xpid"; wait "$xpid" 2>/dev/null || true
set +e
wait "$cpid"; rc=$?
set -e
{
 echo "xio_client_exit=$rc"
 cat "$D/xio.stdout" "$D/xio.stderr"
} >>"$D/results.txt"
cat "$D/results.txt"
