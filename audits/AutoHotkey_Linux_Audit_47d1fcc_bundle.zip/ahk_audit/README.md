# Audit bundle
Frozen repository commit: 47d1fcc2873004f03ba2ee6cc2b1e6e4cada320f

Contents:
- AutoHotkey_Linux_Audit_47d1fcc_zh.md: full Chinese audit, claim ledger, 23 closure items, 13 issues, 35 dimensions, migration corpus and release blockers.
- snapshot.json: frozen metadata. The release publish timestamp retains the minute-level precision actually recovered.
- sources.json: commit-pinned source references.
- issues.json: structured issue register.
- Migration_Corpus_Design_15_zh.md: 15 proposed workloads. These are designs, not executed migration success results.
- probes/: actually executed isolated Xlib contract probes, original source/script/logs.
- reproduce_probes.sh: rebuilds and reruns the isolated probes in a NEW directory.
- SHA256SUMS.txt: hashes for bundle content, excluding the checksum file itself.

Scope:
No full local ahk_core build/test execution is claimed.
Public Actions summaries were checked; the complete remote artifact set was not downloaded.
The ownership probe tests selection ownership interleaving, not MIME payload transfer.
The XIO probe tests libX11 behavior, not an entire AHK process.
Neither probe uses the user's active desktop: the script launches its own Xvfb.

Prerequisites to reproduce probes:
A Linux host with a C compiler, pkg-config, libX11 development files and Xvfb.
Run `sh reproduce_probes.sh /path/to/a/new/output-directory`.
Never overwrite the original evidence directory when rerunning.
