#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST=${1:-"./probe-rerun-$(date -u +%Y%m%dT%H%M%SZ)"}
if [ -e "$DEST" ]; then
  echo "Output directory already exists; use a new directory." >&2
  exit 2
fi
for tool in cc pkg-config Xvfb; do
  command -v "$tool" >/dev/null 2>&1 || { echo "Missing dependency: $tool" >&2; exit 2; }
done
pkg-config --exists x11 || { echo "Missing libX11 development package." >&2; exit 2; }
mkdir -p "$DEST"
cp "$HERE/probes/xio_return_probe.c" "$HERE/probes/clipboard_owner_race_probe.c" "$HERE/probes/run_probes.sh" "$DEST/"
# Flags are obtained from the local pkg-config installation.
cc -O2 -Wall -Wextra "$DEST/xio_return_probe.c" -o "$DEST/xio_return_probe" $(pkg-config --cflags --libs x11)
cc -O2 -Wall -Wextra "$DEST/clipboard_owner_race_probe.c" -o "$DEST/clipboard_owner_race_probe" $(pkg-config --cflags --libs x11)
sh "$DEST/run_probes.sh"
